<?php 
/*
Plugin Name: Vienna Add-On
Plugin URI: http://juarathemes.com/
Description: This plugins includes some functions and features for Vienna Theme. 
Author: Juarathemes
Version: 1.0
Author URI: http://juarathemes.com/
*/ 

require_once 'really-simple-twitter-feed-widget/really_simple_twitter_widget.php';


add_action( 'init', 'register_cpt_album' );

function register_cpt_album() {

    $labels = array( 
        'name' => _x( 'Albums', 'zatolab' ),
        'singular_name' => _x( 'Album', 'zatolab' ),
        'add_new' => _x( 'Add New', 'zatolab' ),
        'add_new_item' => _x( 'Add New Album', 'zatolab' ),
        'edit_item' => _x( 'Edit Album', 'zatolab' ),
        'new_item' => _x( 'New Album', 'zatolab' ),
        'view_item' => _x( 'View Album', 'zatolab' ),
        'search_items' => _x( 'Search Albums', 'zatolab' ),
        'not_found' => _x( 'No albums found', 'zatolab' ),
        'not_found_in_trash' => _x( 'No albums found in Trash', 'zatolab' ),
        'parent_item_colon' => _x( 'Parent Album:', 'zatolab' ),
        'menu_name' => _x( 'Albums', 'zatolab' ),
	);

    $args = array( 
		'labels' => $labels,
        'hierarchical' => false,
        
        'supports' => array( 'title', 'editor', 'thumbnail', 'comments' ),
        
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_icon' => 'dashicons-format-gallery',
        
        
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => true,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => array('slug'=>'album','with_front'=>false),
        'capability_type' => 'post'
    );

	register_post_type( 'zl_album', $args );
}

add_action( 'init', 'register_cpt_zl_portfolio' );

function register_cpt_zl_portfolio() {

    $labels = array( 
        'name' => _x( 'Portfolios', 'zatolab' ),
        'singular_name' => _x( 'Portfolio', 'zatolab' ),
        'add_new' => _x( 'Add New', 'zatolab' ),
        'add_new_item' => _x( 'Add New Portfolio', 'zatolab' ),
        'edit_item' => _x( 'Edit Portfolio', 'zatolab' ),
        'new_item' => _x( 'New Portfolio', 'zatolab' ),
        'view_item' => _x( 'View Portfolio', 'zatolab' ),
        'search_items' => _x( 'Search Portfolios', 'zatolab' ),
        'not_found' => _x( 'No portfolios found', 'zatolab' ),
        'not_found_in_trash' => _x( 'No portfolios found in Trash', 'zatolab' ),
        'parent_item_colon' => _x( 'Parent Portfolio:', 'zatolab' ),
        'menu_name' => _x( 'Portfolios', 'zatolab' ),
    );

    $zl_portfolio_args = array( 
        'labels' => $labels,
        'hierarchical' => false,
        
        'supports' => array( 'title', 'editor', 'thumbnail' ),
        'taxonomies' => array( 'Project Type' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        
        'menu_icon' => 'dashicons-portfolio',
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => true,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );

    register_post_type( 'zl_portfolio', $zl_portfolio_args );
}


add_action( 'init', 'register_taxonomy_project_types' );

function register_taxonomy_project_types() {

    $labels = array( 
        'name' => _x( 'Project Types', 'zatolab' ),
        'singular_name' => _x( 'Project Type', 'zatolab' ),
        'search_items' => _x( 'Search Project Types', 'zatolab' ),
        'popular_items' => _x( 'Popular Project Types', 'zatolab' ),
        'all_items' => _x( 'All Project Types', 'zatolab' ),
        'parent_item' => _x( 'Parent Project Type', 'zatolab' ),
        'parent_item_colon' => _x( 'Parent Project Type:', 'zatolab' ),
        'edit_item' => _x( 'Edit Project Type', 'zatolab' ),
        'update_item' => _x( 'Update Project Type', 'zatolab' ),
        'add_new_item' => _x( 'Add New Project Type', 'zatolab' ),
        'new_item_name' => _x( 'New Project Type', 'zatolab' ),
        'separate_items_with_commas' => _x( 'Separate project types with commas', 'zatolab' ),
        'add_or_remove_items' => _x( 'Add or remove Project Types', 'zatolab' ),
        'choose_from_most_used' => _x( 'Choose from most used Project Types', 'zatolab' ),
        'menu_name' => _x( 'Project Types', 'zatolab' ),
    );

    $args = array( 
        'labels' => $labels,
        'public' => true,
        'show_in_nav_menus' => true,
        'show_ui' => true,
        'show_tagcloud' => false,
        'show_admin_column' => false,
        'hierarchical' => true,

        'rewrite' => true,
        'query_var' => true
    );

    register_taxonomy( 'project_types', array('zl_portfolio'), $args );
}

?>